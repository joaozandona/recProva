

public class Main {
    public static void main(String[] args) throws Exception {
        Animal animal = new Animal();
        animal.setName("Dog");
        animal.setAge(5);
        System.out.println("Name: " + animal.getName());
        System.out.println("Age: " + animal.getAge());
        
    }
}

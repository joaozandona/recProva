public interface Interface {
    public void method1();
    public void method2();
}